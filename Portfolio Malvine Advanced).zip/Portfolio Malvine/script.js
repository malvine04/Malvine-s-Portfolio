// Toggle menu function
function toggleMenu() {
  const menu = document.querySelector(".menu-links");
  const icon = document.querySelector(".hamburger-icon");
  menu.classList.toggle("open");
  icon.classList.toggle("open");
}

// Dark/light mode toggle
function toggleTheme() {
  document.body.classList.toggle("dark-mode");
  
  // Save preference to localStorage
  const isDarkMode = document.body.classList.contains("dark-mode");
  localStorage.setItem("darkMode", isDarkMode);
  
  // Update icon
  const themeIcon = document.querySelector(".theme-toggle i");
  themeIcon.classList.toggle("fa-moon");
  themeIcon.classList.toggle("fa-sun");
  
  // Update mobile icon if exists
  const mobileThemeIcon = document.querySelector(".theme-toggle-mobile i");
  if (mobileThemeIcon) {
    mobileThemeIcon.classList.toggle("fa-moon");
    mobileThemeIcon.classList.toggle("fa-sun");
  }
}

// Typing animation
const textElement = document.querySelector(".sec-text");
const textArray = ["Web Developer", "Student", "Programmer", "Tech Enthusiast"];
let textIndex = 0;
let charIndex = 0;
let isDeleting = false;
let isEnd = false;

function typeText() {
  const currentText = textArray[textIndex];
  
  if (isDeleting) {
    textElement.textContent = currentText.substring(0, charIndex - 1);
    charIndex--;
  } else {
    textElement.textContent = currentText.substring(0, charIndex + 1);
    charIndex++;
  }
  
  if (!isDeleting && charIndex === currentText.length) {
    isEnd = true;
    isDeleting = true;
    setTimeout(typeText, 1500);
  } else if (isDeleting && charIndex === 0) {
    isDeleting = false;
    textIndex++;
    if (textIndex >= textArray.length) textIndex = 0;
    setTimeout(typeText, 500);
  } else {
    const typingSpeed = isDeleting ? 100 : 150;
    setTimeout(typeText, typingSpeed);
  }
}

// Animate progress bars on scroll
function animateProgressBars() {
  const skillsSection = document.getElementById("experience");
  const progressBars = document.querySelectorAll(".progress");
  
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        progressBars.forEach(bar => {
          const width = bar.style.width;
          bar.style.width = "0";
          setTimeout(() => {
            bar.style.width = width;
          }, 100);
        });
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.5 });
  
  if (skillsSection) {
    observer.observe(skillsSection);
  }
}

// Smooth scroll for anchor links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener("click", function(e) {
    e.preventDefault();
    
    const targetId = this.getAttribute("href");
    if (targetId === "#") return;
    
    const targetElement = document.querySelector(targetId);
    if (targetElement) {
      window.scrollTo({
        top: targetElement.offsetTop - 100,
        behavior: "smooth"
      });
      
      // Close mobile menu if open
      const menu = document.querySelector(".menu-links");
      const icon = document.querySelector(".hamburger-icon");
      if (menu.classList.contains("open")) {
        menu.classList.remove("open");
        icon.classList.remove("open");
      }
    }
  });
});

// Form submission
const contactForm = document.getElementById("contactForm");
if (contactForm) {
  contactForm.addEventListener("submit", function(e) {
    e.preventDefault();
    
    const formData = new FormData(this);
    const submitBtn = this.querySelector(".submit-btn");
    
    submitBtn.disabled = true;
    submitBtn.textContent = "Sending...";
    
    // Simulate form submission (in a real scenario, you would use fetch or AJAX)
    setTimeout(() => {
      submitBtn.textContent = "Message Sent!";
      submitBtn.style.backgroundColor = "#2ecc71";
      this.reset();
      
      setTimeout(() => {
        submitBtn.textContent = "Send Message";
        submitBtn.style.backgroundColor = "";
        submitBtn.disabled = false;
      }, 3000);
    }, 1500);
  });
}

// Initialize theme from localStorage
function initTheme() {
  const darkMode = localStorage.getItem("darkMode") === "true";
  if (darkMode) {
    document.body.classList.add("dark-mode");
    const themeIcon = document.querySelector(".theme-toggle i");
    if (themeIcon) {
      themeIcon.classList.remove("fa-moon");
      themeIcon.classList.add("fa-sun");
    }
  }
}

// Initialize everything when DOM is loaded
document.addEventListener("DOMContentLoaded", function() {
  initTheme();
  
  // Set up theme toggle
  const themeToggle = document.querySelector(".theme-toggle");
  if (themeToggle) {
    themeToggle.addEventListener("click", toggleTheme);
  }
  
  const mobileThemeToggle = document.querySelector(".theme-toggle-mobile");
  if (mobileThemeToggle) {
    mobileThemeToggle.addEventListener("click", toggleTheme);
  }
  
  // Start typing animation if element exists
  if (textElement) {
    setTimeout(typeText, 1000);
  }
  
  // Set up progress bar animation
  animateProgressBars();
  
  // Add animation to sections on scroll
  const sections = document.querySelectorAll("section");
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.style.opacity = 1;
        entry.target.style.transform = "translateY(0)";
      }
    });
  }, { threshold: 0.1 });
  
  sections.forEach(section => {
    section.style.opacity = 0;
    section.style.transform = "translateY(20px)";
    section.style.transition = "opacity 0.5s ease, transform 0.5s ease";
    observer.observe(section);
  });
});